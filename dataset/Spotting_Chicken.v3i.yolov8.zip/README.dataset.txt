# Spotting_Chicken > 2024-12-20 11:38pm
https://universe.roboflow.com/yolotrain-fnxv3/spotting_chicken

Provided by a Roboflow user
License: CC BY 4.0

