# Spotting_Chicken > 2024-12-15 2:27pm
https://universe.roboflow.com/yolotrain-fnxv3/spotting_chicken

Provided by a Roboflow user
License: CC BY 4.0

